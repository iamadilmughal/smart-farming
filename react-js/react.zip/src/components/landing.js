import React, { Component } from "react";
import { Grid, Cell } from "react-mdl";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserAlt, faEye, faEdit } from "@fortawesome/free-solid-svg-icons";
import "./landing.css"

class landing extends Component {
  render() {
    return (
      <div className="mainBody">
        <div className="cellDiv">
          <div className="iconDiv">
            <FontAwesomeIcon icon={faUserAlt} style={{ marginRight: "10px" }} />
          </div>
          <div className="titleDiv">
            <h2>Users</h2>
          </div>
          <div className="linksDiv">
            <div className="singleLink">
              <FontAwesomeIcon icon={faEye} style={{ marginRight: "10px" }} />
              <p>View Experts</p>
            </div>
            <div className="singleLink">
              <FontAwesomeIcon icon={faEye} style={{ marginRight: "10px" }} />
              <p>View Admins</p>
            </div>
            <div className="singleLink">
              <FontAwesomeIcon icon={faEye} style={{ marginRight: "10px" }} />
              <p>View Farmers</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default landing;
