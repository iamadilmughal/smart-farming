import React, {Component} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPencilAlt,faTrashAlt } from '@fortawesome/free-solid-svg-icons'
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import { faPencilAlt,faTrashAlt } from '@fortawesome/free-solid-svg-icons'


const Todo = props => (
    <tr>
        <td>{props.todo.name}</td>
        <td>{props.todo.Date}</td>
        <td>{props.todo.Time}</td>
        <td>{props.todo.Tpeoples}</td>
        <td>{props.todo.notes}</td>
     
       
    import "./viewr.css";
    </tr>
)

export default class TodosList extends Component {

    constructor(props) {
        super(props);
        this.state = {todos: []};
    }

    componentDidMount() {
        axios.get('http://localhost:5000/restaurant/reserve')
            .then(response => {
                this.setState({todos: response.data});
                console.log(response)
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    

    todoList() {
        return this.state.todos.map((todos, index) => {
            const { name, lastName, Date, Time, confirmed, notes,Tpeoples } = todos //destructuring
            return (
               <tr key={index}>
                  <td>{name}</td>
                 
                  <td>{Date}</td>
                  <td>{Time}</td>
                  <td>{Tpeoples}</td>
                 
                
                   <td>
         
            <Link to={"/editr/"+todos._id}>
            Confirm Order
            </Link>
        </td>
        <td>
            <Link to={"/deleter/"+todos._id}>
           Cancel Order

            </Link>
        </td> 
        
               </tr>
            )
         })

        // return this.state.todos.map(function(currentTodo, i) {
        //     return <Todo todo={currentTodo} key={i} />;
        // });
    }

    render() {
        return (
            <div>
                <h1 id='title'>Reservation Details</h1>
                


                 <table id='todos'className="table table-striped" style={{ marginTop: 20 }}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Number of peoples</th>
                            <th>Action</th>
                            <th>Action</th>                           
                        </tr>
                    </thead>
                    <tbody>
                        { this.todoList() }
                    </tbody>
                </table> 
            </div>
        )
    }
}
