import React, { Component } from "react";
import "./restaurantdetails.css";
import Axios from "axios";

const formValid = ({ formErrors, ...rest }) => {
  let valid = true;

  // validate form errors being empty
  Object.values(formErrors).forEach(val => {
    val.length > 0 && (valid = false);
  });

  // validate the form was filled out
  Object.values(rest).forEach(val => {
    val === null && (valid = false);
  });

  return valid;
};

class restaurantdetails extends Component {
  constructor(props) {
    super(props);
    this.handleChange1 = this.handleChange1.bind(this);
    this.handleChange2 = this.handleChange2.bind(this);
    this.handleChange3 = this.handleChange3.bind(this);

    this.state = {
      name: null,
      // addedby: null,
      value: null,
      value1: "disease1",
      value2: "pest1",

      description: null,

      selectedFile: "",
      formErrors: {
        name: "",
        addedby: "",

        description: ""
      }
    };
  }
  handleChange1(event) {
    event.preventDefault();
    this.setState({ value: event.target.value });
  }
  handleChange2(event) {
    event.preventDefault();
    this.setState({ value1: event.target.value1 });
  }
  handleChange3(e) {
    const { value2 } = e.target;
    this.setState({ value2: value2 }, () => console.log(this.state));
  }

  onChangeHandler = event => {
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    // alert("clicked");
    let ab = {
      a: this.state.name,
      b: this.state.value2
    };
    console.log(ab);

    if (formValid(this.state)) {
      // let data = new FormData();
      let data = {
        name: this.state.name,
        season: this.state.value,
        disease: this.state.value1,
        pest: this.state.value2,
        description: this.state.description,
        file: this.state.selectedFile
      };

      // data.push("name", this.state.name);
      // // data.append("addedby", this.state.addedby);
      // data.push("season", this.state.value);
      // data.push("disease", this.state.value1);
      // data.push("pest", this.state.value2);
      // data.push("description", this.state.description);
      // data.push("file", this.state.selectedFile);

      console.log(data);
      // alert(data);

      Axios.post("http://localhost:3000/plant", data)
        .then(res => {
          // console.log(res.data);
        })
        .catch(error => {
          console.log(error);
        });
    } else {
      alert(this.state.formErrors.toString());
    }
  };

  handleChange = e => {
    e.preventDefault();
    const { name, value } = e.target;
    let formErrors = { ...this.state.formErrors };

    switch (name) {
      case "name":
        formErrors.name =
          value.length < 3 ? "minimum 3 characaters required" : "";
        break;

      case "description":
        formErrors.description =
          value.length < 10 ? "minimum 10 characaters required" : "";
        break;

      default:
        break;
    }
    if (name == "1") {
      this.setState({
        value: value
      });
    } else if (name == "2") {
      this.setState({
        value1: value
      });
    } else if (name == "3") {
      this.setState({
        value2: value
      });
    }
    this.setState({ formErrors, [name]: value }, () => console.log(this.state));
  };

  render() {
    const { formErrors } = this.state;

    return (
      <div className="wrapper">
        <div className="form-wrapper">
          <h1>Add Plant Details</h1>
          <form onSubmit={this.handleSubmit} noValidate>
            <div className="name">
              <label htmlFor="name">Plant Name*</label>
              <input
                className={formErrors.name.length > 0 ? "error" : null}
                placeholder="Plant Name"
                type="text"
                name="name"
                noValidate
                onChange={this.handleChange}
              />
              {formErrors.name.length > 0 && (
                <span className="errorMessage">{formErrors.name}</span>
              )}
            </div>

            <div className="description">
              <label htmlFor="description">Description*</label>
              <input
                className={formErrors.description.length > 0 ? "error" : null}
                placeholder="Description"
                type="text"
                name="description"
                noValidate
                onChange={this.handleChange}
              />
              {formErrors.description.length > 0 && (
                <span className="errorMessage">{formErrors.description}</span>
              )}
            </div>
            {/* <div className="addedby">
              <label htmlFor="addedby">Added By*</label>
              <input
                className={formErrors.description.length > 0 ? "error" : null}
                placeholder="Added By"
                type="text"
                name="addedby"
                noValidate
                onChange={this.handleChange}
              />
              {formErrors.addedby.length > 0 && (
                <span className="errorMessage">{formErrors.addedby}</span>
              )}
            </div> */}
            <div className="season">
              <label htmlFor="season">Select Season*</label>
              <select
                name="1"
                value={this.state.value}
                onChange={this.handleChange}
              >
                <option value="winter">Winter</option>
                <option value="summer">Summer</option>
                <option value="autumn">Autumn</option>
                <option value="spring">Spring</option>
              </select>
            </div>
            <div className="disease">
              <label htmlFor="disease">Select Disease*</label>
              <select
                name="2"
                value1={this.state.value}
                onChange={this.handleChange}
              >
                <option value1="disease1">Disease 1</option>
                <option value1="disease2">Disease 2</option>
                <option value1="disease3">Disease 3</option>
                <option value1="disease4">Disease 4</option>
              </select>
            </div>
            <div className="pest">
              <label htmlFor="pest">Select Pest*</label>
              <select
                name="3"
                value2={this.state.value}
                onChange={this.handleChange}
              >
                <option value2="pest1">Pest 1</option>
                <option value2="pest2">Pest 2</option>
                <option value2="pest3">Pest 3</option>
                <option value2="pest4">Pest 4</option>
              </select>
            </div>

            <div className="container">
              <div className="row">
                <div className="col-md-6">
                  <div className="form-group files">
                    <label>Upload a Plant Picture</label>
                    <input
                      type="file"
                      name="file"
                      multiple
                      onChange={this.onChangeHandler}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="login">
              <button type="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default restaurantdetails;
