import React, { Component } from "react";
import {DataTable, TableHeader, Textfield} from 'react-mdl';
import './rtable.css';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPencilAlt,faTrashAlt } from '@fortawesome/free-solid-svg-icons'

import { Link } from 'react-router-dom';


const Todo = props => (
  <tr>
      <td>{props.todo.name}</td>
      <td>{props.todo.type}</td>
      <td>{props.todo.price}</td>
      <td>{props.todo.description}</td>
      <td>{props.todo.image}</td>
     
      <td>

          <Link to={"/editfood/"+props.todo._id}>Edit</Link>
      </td>
  </tr>
)


class rtable extends Component {

  constructor(props) {
    super(props);
    this.state = {todos: []};
}

componentDidMount() {
    axios.get('http://localhost:5000/food/')
        .then(response => {
            this.setState({todos: response.data});
            console.log(response.data)
        })

        .catch(function (error) {
            console.log(error);
        })
}



todoList() {
   

    return this.state.todos.map(function(currentTodo, i) {
        return <Todo todo={currentTodo} key={i} />;
    });
}

  render() {

    return (
      
      <div className="det">
      

        <h1> Product Details</h1>
        <table id='todos'className="table table-striped" style={{ marginTop: 20 }}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Price</th>
                          
                          
                            <th>Description</th>
                            <th>image</th>
                            <th>Action</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.todoList() }
                    </tbody>
                </table> 

       
      </div>
    );
  }
}

export default rtable;