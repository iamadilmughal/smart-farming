import React, {Component} from 'react';
import { Link } from 'react-router-dom';
import "./viewr.css";
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPencilAlt,faTrashAlt } from '@fortawesome/free-solid-svg-icons'
 

const Todo = props => (
    <tr>
        <td>{props.todo.name}</td>
        <td>{props.todo.email}</td>
        <td>{props.todo.contactNumber}</td>
        <td>{props.todo.foods.food}</td>
        <td>{props.todo.estimatedDeliveryTime}</td>
        <td>{props.todo.description}</td>
        <td>
            <Link to={"/editr/"+props.todo._id}>Edit</Link>
        </td>
    </tr>
)

export default class TodosList extends Component {

    constructor(props) {
        super(props);
        this.state = {todos: []};
    }

    componentDidMount() {
        axios.get('http://localhost:5000/restaurant/')
            .then(response => {
                this.setState({todos: response.data});
                console.log(response.data)
            })

            .catch(function (error) {
                console.log(error);
            })
    }

    

    todoList() {
        return this.state.todos.map((todos, index) => {
            const { name, email, contactNumber, cuisine,estimatedDeliveryTime,description, address,image,foods} = todos //destructuring
            return (
               <tr key={index}>
                  <td>{name}</td>
                  <td>{email}</td>
                  <td>{contactNumber}</td>
                  <td>{cuisine}</td>
                  <td>{estimatedDeliveryTime}</td>
                  <td>{description}</td>
                  <td>{address}</td>
                  <td>{image}</td>
                 

                  <td>
            <Link to={"/editr/"+todos._id}>
            <FontAwesomeIcon icon={faPencilAlt} />
            </Link>
        </td>
        <td>
            <Link to={"/deleter/"+todos._id}>
            <FontAwesomeIcon icon={faTrashAlt} />

            </Link>
        </td>
        
               </tr>
            )
         })

    }

    render() {
        return (
            <div className="details">
                <h1 id='title'>Restaurant Details</h1>
                


                 <table id='todos'className="table table-striped" style={{ marginTop: 20 }}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact Number</th>
                            <th>Cuisine</th>
                            <th>Estimated Delivery Time</th>
                            <th>Description</th>
                            <th>Address</th>
                            <th>Image</th>
                           
                            <th>Action</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.todoList() }
                    </tbody>
                </table> 
            </div>
        )
    }
}
